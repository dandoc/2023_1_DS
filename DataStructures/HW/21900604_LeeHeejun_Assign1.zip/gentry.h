typedef struct {
	char * name ;
	int score ;
} gentry ;

